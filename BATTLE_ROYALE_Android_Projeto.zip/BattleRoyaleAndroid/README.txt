BATTLE ROYALE — projeto Android inicial

Este é o projeto-fonte de um wrapper Android para o protótipo. Ele ainda NÃO é um APK compilado.
Para gerar o APK:
1. Abra a pasta BattleRoyale no Android Studio atualizado.
2. Aguarde a sincronização do Gradle.
3. Use Build > Build Bundle(s) / APK(s) > Build APK(s).
4. O APK de teste será criado em app/build/outputs/apk/debug/app-debug.apk.

Notas:
- O protótipo usa Three.js via CDN, então precisa de internet para carregar o motor 3D.
- Multiplayer online real não está implementado.
- Teste no seu aparelho antes de distribuir; este projeto é experimental.
